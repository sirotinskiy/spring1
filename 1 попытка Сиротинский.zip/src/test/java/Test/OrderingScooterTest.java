package Test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import yandex_samokat_po.AboutPageRent;
import yandex_samokat_po.MainPageScreen;
import yandex_samokat_po.WhoIsTheScooterForPage;

import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;

public class OrderingScooterTest {

    private WhoIsTheScooterForPage whoIsTheScooterForPage;
    private AboutPageRent aboutPageRent;
    private MainPageScreen mainPageScreen;

    @Before
    public void setUp() throws Exception {
        mainPageScreen = open("https://qa-scooter.praktikum-services.ru/", MainPageScreen.class);
        whoIsTheScooterForPage = open("https://qa-scooter.praktikum-services.ru/", WhoIsTheScooterForPage.class);
        aboutPageRent = open("https://qa-scooter.praktikum-services.ru/", AboutPageRent.class);

    }

    @After
    public void tearDown() throws Exception {
        close();
    }

    @Test
    public void orderingScooterViaHeaderButton() {
        String expectTextOrderIsDone = "Номер заказа: ";

        mainPageScreen.clickButtonHeaderOrder();

        whoIsTheScooterForPage.setCardRental("Борис",
                                            "Бритва",
                                            " ул. Казакова 8 ",
                                            "Курская",
                                            "89995502634");
        whoIsTheScooterForPage.clickButtonNext();

        aboutPageRent.setCardAboutRent("04.05.2022",
                                        3,
                                        "black",
                                        "Я не умею кататься");
        aboutPageRent.ordering();

        Assert.assertThat(aboutPageRent.getNumberOrder(),equalTo(expectTextOrderIsDone));
    }

    @Test
    public void orderingScooterViaMidlButton() {
        String expectTextOrderIsDone = "Номер заказа: ";

        mainPageScreen.clickButtonMidlOrder();

        whoIsTheScooterForPage.setCardRental("Константин",
                "Дядька",
                "проспект Вернадского",
                "Парк Культуры",
                "+79992203388");
        whoIsTheScooterForPage.clickButtonNext();

        aboutPageRent.setCardAboutRent("5.06.2022",
                4,
                "grey",
                "Я не умею кататься");
        aboutPageRent.ordering();

        Assert.assertThat(aboutPageRent.getNumberOrder(),containsString(expectTextOrderIsDone));
    }

}

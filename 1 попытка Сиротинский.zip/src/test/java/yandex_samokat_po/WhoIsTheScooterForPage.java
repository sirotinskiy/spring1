package yandex_samokat_po;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.support.FindBy;

public class WhoIsTheScooterForPage {
    //Поле ввода имени
    @FindBy(xpath = "//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/input")
    private SelenideElement inputFieldName;

    //Поле ввода фамилии
    @FindBy(xpath = "/html/body/div/div/div[2]/div[2]/div[2]/input")
    private SelenideElement inputFieldLastName;

    //Поле ввода адреса, куда привезти заказ
    @FindBy(xpath = "//*[@id=\"root\"]/div/div[2]/div[2]/div[3]/input")
    private SelenideElement inputFieldAddress;

    //Поле ввода метро
    @FindBy(xpath = "//*[@id=\"root\"]/div/div[2]/div[2]/div[4]/div/div/input")
    private SelenideElement inputFieldMetro;

    //Выпадающий список найденных станций
    @FindBy(xpath = "/html/body/div/div/div[2]/div[2]/div[4]/div/div[2]")
    private ElementsCollection dropDownListMetro;

    //Поле ввода номера телефона
    @FindBy(xpath = "//*[@id=\"root\"]/div/div[2]/div[2]/div[5]/input")
    private SelenideElement inputFieldPhoneNumber;

    //Кнопка далее
    @FindBy(xpath = "//*[@id=\"root\"]/div/div[2]/div[3]/button")
    private SelenideElement buttonNext;

    public void setInputFieldName(String name) {
        inputFieldName.setValue(name);
    }

    public void setInputFieldLastName(String LastName) {
        inputFieldLastName.setValue(LastName);
    }

    public void setInputFieldAddress(String address) {
        inputFieldAddress.setValue(address);
    }

    public void setInputFieldMetro(String metro) {
        inputFieldMetro.setValue(metro);
        dropDownListMetro.get(0).click();
    }

    public void setInputFieldPhoneNumber(String phoneNumber) {
        inputFieldPhoneNumber.setValue(phoneNumber);
    }

    public void clickButtonNext(){
        buttonNext.click();
    }

    public void setCardRental(String name, String lastName, String address,
                              String metro, String phoneNumber){
        setInputFieldName(name);
        setInputFieldLastName(lastName);
        setInputFieldAddress(address);
        setInputFieldMetro(metro);
        setInputFieldPhoneNumber(phoneNumber);
    }

}
